상태: 완료
요약: 판정 146 · ①② 통과 109 · 그중 ③만 [FAIL] 0
판정할 것: 0건

[PASS] control: denied file readable without sandbox
[PASS] denied file NOT readable in sandbox
[PASS] denied folder NOT listable in sandbox
[PASS] work folder writable in sandbox
[PASS] outside work folder NOT writable in sandbox

