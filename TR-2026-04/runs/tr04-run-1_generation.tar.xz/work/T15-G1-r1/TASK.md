# 과제 T15 — 셀 B 빈칸 채우기: 출력

## 할 일

`base.ldprog.json` 은 셀 B의 완성된 래더에서 「출력」 기능 묶음 렁 24 개를 뺀 것이다. 빠진 렁은 base 의 렁 목록에서 번호 514 자리(0 부터 센다, 그 앞 렁 뒤)에 들어간다. 빠진 기능을 사양서대로 다시 만든다.

만들 파일: `out/blank.json` — `{"tags": [새로 선언할 내부 태그], "rungs": [끼울 렁들, 순서대로]}`.

끼울 렁이 읽어야 하는 태그(렁 밖에서 오는 것): `B.HMI.strokeWarn`, `D_누적스캔`, `D_밀기단계`, `D_복귀내부상태`, `D_운전모드`, `D_첫고장코드`, `M_복귀전진요구`, `M_복귀후진요구`, `M_안전허가`, `M_알람_AIR_NO_MOTION`, `M_알람_AIR_PRESSURE_LOW`, `M_알람_ARRIVAL_OVERLAP`, `M_알람_ARRIVAL_SPACING`, `M_알람_BRAKE_NOT_ENGAGED`, `M_알람_BRAKE_NOT_RELEASED`, `M_알람_CHUTE_CONFIRM_MISSING`, `M_알람_CHUTE_CONFIRM_TIMING`, `M_알람_CHUTE_QUEUE_FULL`, `M_알람_CONVEYOR_OVERLOAD`, `M_알람_HOME_TIMEOUT`, `M_알람_INSPECTION_NOT_READY`, `M_알람_JOB_QUEUE_FULL`, `M_알람_OUT_CONFIRM_MISSING`, `M_알람_OUT_CONFIRM_TIMING`, `M_알람_OUT_QUEUE_FULL`, `M_알람_PULSE_COUNTER_INVALID`, `M_알람_PULSE_LOST`, `M_알람_PURGE_TIMEOUT`, `M_알람_PUSH_TIMEOUT`, `M_알람_RETRACT_TIMEOUT`, `M_알람_RETURN_PREDICTED_LATE`, `M_알람_SAFETY_STOP`, `M_알람_SORT_LATE`

끼울 렁이 정해야 하는 태그(렁 밖에서 읽히거나 출력인 것): `B.Buzzer`, `B.Conv.run`, `B.Feed.hold`, `B.Lamp.green`, `B.Lamp.red`, `B.Lamp.strokeWarn`, `B.Lamp.yellow`, `B.Psh.sol`, `B.Recovery.finishPush`, `B.Recovery.retract`, `B.Stp.sol`, `M_구동이력`

base 에 이미 있는 태그 289 개는 다시 선언하지 않는다. 새 내부 태그의 주소는 base 의 주소와 겹치지 않게 한다.

## 읽을 파일

- 사양서: `spec/TR-04_사양서_셀B_v1.md`
- 부록(엔진이 받는 요소와 명령): `appendix.md`
- 입출력 표: `io.json` (이름·주소·형식을 바꾸지 않는다. `use` 가 `required` 인 입력은 읽고 출력은 정한다)
- 빈칸이 빠진 래더: `base.ldprog.json`

## 규칙

- 사양서와 부록만 근거로 쓴다. 이 폴더 밖 파일은 없다고 생각한다.
- `marker` 필드는 쓰지 않는다. 판정기가 붙인다.
- 만들 파일 하나만 쓴다. 설명 문장은 파일 안에 넣지 않는다(렁 `comment` 는 써도 된다).
- 시뮬레이터나 검사기는 없다. 파일을 낸 뒤 판정기가 컴파일하고, 오류가 나면 오류 문장을 돌려준다(최대 2 회).
