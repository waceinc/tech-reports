# 과제 T20 — 포장 셀 빈칸 채우기: 출력

## 할 일

`base.ldprog.json` 은 포장 셀의 완성된 래더에서 「출력」 기능 묶음 렁 34 개를 뺀 것이다. 빠진 렁은 base 의 렁 목록에서 번호 819 자리(0 부터 센다, 그 앞 렁 뒤)에 들어간다. 빠진 기능을 사양서대로 다시 만든다.

만들 파일: `out/blank.json` — `{"tags": [새로 선언할 내부 태그], "rungs": [끼울 렁들, 순서대로]}`.

끼울 렁이 읽어야 하는 태그(렁 밖에서 오는 것): `D_C0응답단계`, `D_C1응답단계`, `D_R0요청수량`, `D_R0응답단계`, `D_R0적재행`, `D_R1요청수량`, `D_R1응답단계`, `D_R1적재행`, `D_Tote응답단계`, `D_램프위상`, `D_포장첫고장코드`, `M_포장고장해제`, `M_포장신규요청허가`, `M_포장안전정지`, `M_포장원인활성`, `M_포장재기동`, `M_포장허가`, `P.C0.busy`, `P.C0.present`, `P.C0.stockLow`, `P.C1.busy`, `P.C1.present`, `P.C1.stockLow`, `P.Safety.permit`, `P.Tote.busy`, `P.Tote.count`, `P.Tote.done`, `P.Tote.full`, `P.Tote.present`, `P.Tote.stockLow`

끼울 렁이 정해야 하는 태그(렁 밖에서 읽히거나 출력인 것): `P.C0.ack`, `P.C0.request`, `P.C0.reset`, `P.C1.ack`, `P.C1.request`, `P.C1.reset`, `P.Feed.ready`, `P.Lamp.stock`, `P.R0.ack`, `P.R0.mask`, `P.R0.request`, `P.R0.request_count`, `P.R0.reset`, `P.R0.row`, `P.R1.ack`, `P.R1.mask`, `P.R1.request`, `P.R1.request_count`, `P.R1.reset`, `P.R1.row`, `P.Reject.gate`, `P.Safety.enable`, `P.Tote.ack`, `P.Tote.request`, `P.Tote.reset`

base 에 이미 있는 태그 518 개는 다시 선언하지 않는다. 새 내부 태그의 주소는 base 의 주소와 겹치지 않게 한다.

## 읽을 파일

- 사양서: `spec/TR-04_사양서_셀B_v1.md`, `spec/TR-04_사양서_포장셀_v1.md`
- 부록(엔진이 받는 요소와 명령): `appendix.md`
- 입출력 표: `io.json` (이름·주소·형식을 바꾸지 않는다. `use` 가 `required` 인 입력은 읽고 출력은 정한다)
- 빈칸이 빠진 래더: `base.ldprog.json`

## 규칙

- 사양서와 부록만 근거로 쓴다. 이 폴더 밖 파일은 없다고 생각한다.
- `marker` 필드는 쓰지 않는다. 판정기가 붙인다.
- 만들 파일 하나만 쓴다. 설명 문장은 파일 안에 넣지 않는다(렁 `comment` 는 써도 된다).
- 시뮬레이터나 검사기는 없다. 파일을 낸 뒤 판정기가 컴파일하고, 오류가 나면 오류 문장을 돌려준다(최대 2 회).
